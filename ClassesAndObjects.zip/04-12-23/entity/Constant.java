package entity;

public class Constant {

  public static final double PI = 3.14;

  public double ABC = 123;

  private static double XYZ = 123;

  private double GHI = 123;

}
