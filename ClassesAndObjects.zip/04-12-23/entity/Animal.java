package entity;

public class Animal {

  public void xyz() {
    System.out.print("Hello from Animal");
  }

}
