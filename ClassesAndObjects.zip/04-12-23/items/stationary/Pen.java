package items.stationary;

public class Pen {

}
